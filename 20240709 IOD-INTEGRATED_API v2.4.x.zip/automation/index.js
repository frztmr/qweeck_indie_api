const trademarkMgmtAuto = require('./trademarkMgmt')
const notification = require('./notification')


module.exports = {
    trademarkMgmtAuto, 
    notification
};
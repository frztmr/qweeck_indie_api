const { json } = require("body-parser");
const { dbConf, dbQuery, addSqlLogger } = require("../config/db");

let magenta = "\x1b[35m"
module.exports = {
  getPoWeek: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';
    // timestamp + 
    // let { company_id } = req.body

    try {
      if (req.dataToken.user_id) {

        let query = `
        SELECT DISTINCT 
        mo.delv_week, mo.delv_week_desc, mo.cart_id, date_format(mo.created_date,'%Y-%m-%d-%T ') created_date 
        FROM 
        m_cart mo
        JOIN mst_company mco ON mo.company_id = mco.company_id  
        LEFT JOIN map_port_for_dist mpfd ON mo.port_shipment = mpfd.harbour_id 
        AND mo.company_id  = mpfd.distributor_id  
        LEFT JOIN mst_company stp ON stp.company_id = mo.ship_to 
        LEFT JOIN sys_user su ON su.user_id = mo.created_by  
        WHERE mo.company_id = ${req.dataToken.company_id} ;
       `;
        dbConf.query(query, (err, results) => {
          if (err) {
            res.status(500).send(err);
            console.log(timestamp + "Error! at get", err);
          } else {
            res.status(200).send(results);
            console.log(timestamp + `get cart PoWeek at Cart: ${req.dataToken.company_id}`);
            addSqlLogger(req.dataToken.user_id, '-- query data cart', '-- data cart', 'getPoWeek');
          }
        }
        );
      } else {
        res.status(200).send({
          success: false,
          message: "unauthorized",
        });
      }
    } catch (error) {
      console.log(timestamp + error);
      res.status(500).send(error);
    }
  },
  getCartHeader: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';
    // timestamp + 

    // revision ver 4.4: pattch: added some query
    // revisin 20240508: 1 user hanya bisa melihat draft 1 user itu sendiri bukan per company

    try {
      if (req.dataToken.user_id) {
        dbConf.query(
          `
            SELECT DISTINCT 
            mc.cart_id, mco.company_name, mc.delv_week, mc.delv_week_desc, mc.delv_year, mc.id_year,
            mc.po_buyer, mpfd.final_dest , mc.po_buyer, stp.company_name , 
            mc.po_url, su.firstname  created_by, mcd.cont_size, 
            mcd.cont_qty, mct.container_name, 
            date_format(mc.created_date,'%Y-%m-%d-%T ') created_date,
            mc.port_shipment, mpfd.harbour_id 
            FROM 
                    m_cart mc
                    JOIN mst_company mco ON mc.company_id = mco.company_id  
                    LEFT JOIN map_port_for_dist mpfd ON mc.port_shipment = mpfd.harbour_id 
                    AND mc.company_id  = mpfd.distributor_id  
                    LEFT JOIN mst_company stp ON stp.company_id = mc.ship_to 
                    LEFT JOIN sys_user su ON su.user_id = mc.created_by 
                    LEFT JOIN m_cart_dtl mcd ON mc.cart_id = mcd.cart_id 
                    LEFT JOIN mst_container mct ON mct.container_id = mcd.cont_size 
                    WHERE mc.created_by  = ${req.dataToken.user_id} ;
                        `,
          (err, results) => {
            if (err) {
              res.status(500).send(err);
              console.log(timestamp + "Error!", err);
            } else {
              res.status(200).send(results);
              console.log(timestamp + `get cart Header success: ${req.dataToken.user_id}`);
              addSqlLogger(req.dataToken.user_id, '-- query data cart', '-- data cart', 'getCartHeader');
            }
          }
        );
      } else {
        res.status(200).send({
          success: false,
          message: "unauthorized",
        });
      }
    } catch (error) {
      console.log(timestamp + error);
      res.status(500).send(error);
    }
  },
  getCartDetail: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';

    // revisin 20240508: 1 user hanya bisa melihat draft 1 user itu sendiri bukan per company

    try {
      if (req.dataToken.user_id) {
        let query = `
        SELECT 
        det.cart_id, det.company_id, mco.company_name, det.created_by, su.firstname,  
        det.detail_id, det.cont_size, mc.container_name, det.cont_qty, 
        det.sku1,COALESCE(mp1.product_name_no, mp1.product_name) product_name_1,
        mpl1.img url_1, det.qty1,det.price1, mp1.product_sku prod_sku1,
        det.sku2,COALESCE(mp2.product_name_no, mp2.product_name) product_name_2,
        mpl2.img url_2, det.qty2,det.price2, mp2.product_sku prod_sku2,
        det.sku3,COALESCE(mp3.product_name_no, mp3.product_name) product_name_3,
        mpl3.img url_3, det.qty3, det.price3, mp3.product_sku prod_sku3,
        det.remarks, det.bulk, det.delv_week, det.delv_year, det.id_year
        FROM 
        m_cart_dtl det
        JOIN mst_company mco ON det.company_id = mco.company_id  
        LEFT JOIN sys_user su ON su.user_id = det.created_by 
        LEFT JOIN mst_container mc ON mc.container_id = det.cont_size
        LEFT JOIN mst_product mp1 ON det.sku1 = mp1.product_code
        LEFT JOIN mst_product mp2 ON det.sku2 = mp2.product_code
        LEFT JOIN mst_product mp3 ON det.sku3 = mp3.product_code
        LEFT JOIN m_product_link mpl1 ON det.sku1 = mpl1.product_code 
        LEFT JOIN m_product_link mpl2 ON det.sku2 = mpl2.product_code 
        LEFT JOIN m_product_link mpl3 ON det.sku3 = mpl3.product_code 
        WHERE det.created_by = ${req.dataToken.user_id} 
        ORDER BY det.delv_week, det.cart_id , det.detail_id ;
        `
        dbConf.query(query, (err, results) => {
          if (err) {
            res.status(500).send(err);
            console.log(timestamp + "Error!", err);
          } else {
            res.status(200).send(results);
            console.log(timestamp + `get cart Detail: ${req.dataToken.company_id}`);
            addSqlLogger(req.dataToken.user_id, '-- query data cart', '-- data cart', 'getCartDetail');
          }
        });

      } else {
        res.status(200).send({
          success: false,
          message: "unauthorized",
        });
      }
    } catch (error) {
      console.log(timestamp + error);
      res.status(500).send(error);
    }
  },
  delete: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';
    // timestamp + 


    if (req.dataToken.user_id) {

      //   let { company_id, created_date } = req.body;
      //   let rev_created_date = "'" + created_date + "'";

      let { created_date } = req.body;

      if (created_date) {

        let query = `
        DELETE FROM m_cart WHERE company_id = ${req.dataToken.company_id} 
        AND created_date = ?; 
        
        DELETE FROM m_cart_dtl WHERE company_id = ${req.dataToken.company_id} 
        AND created_date = ?; 
        `
        let parameter = [created_date, created_date];
        dbConf.query(query, parameter,
          (err, results) => {
            if (err) {
              res.status(500).send(err);
              console.log(timestamp + "Error while deleteing cart:", err);
            } else {
              res.status(200).send(results);
              console.log(timestamp + "delete Cart for : ", req.dataToken.company_id + "| Created Date: " + created_date);
              addSqlLogger(req.dataToken.user_id, (query.concat(parameter)), (JSON.stringify(results)), 'deleteCart');
            }
          }
        );
      } else {
        res.status(200).send();
        console.log(timestamp + "cart is not deleted :/ ");
        addSqlLogger(req.dataToken.user_id, '--cart is not deleted', '-- warning, cart is not deleted', 'deleteCart');
      }

    } else {
      res.status(200).send({
        success: false,
        message: "unauthorized",
      });
    }

  },
  addCartHeader: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';
    // timestamp + 
    if (req.dataToken.user_id) {

      let {
        cart_id,
        user_id,
        company_id,
        delv_week,
        delv_week_desc,
        delv_year,
        id_year,
        po_buyer,
        port_shipment,
        ship_to,
        po_url,
      } = req.body;

      let query = ` INSERT INTO m_cart 
                    (cart_id, company_id, delv_week, delv_week_desc, delv_year, id_year, po_buyer, 
                      created_date, port_shipment, ship_to, po_url, created_by )
                     VALUES
                      (?, ?, ?, ?, ?, ?, ?, date_format(now(),'%Y-%m-%d-%T '), ?, ?, ?, ?); 
                  `

      let parameter = [cart_id, company_id, delv_week, delv_week_desc, delv_year, id_year, po_buyer, port_shipment, ship_to, po_url, user_id]

      dbConf.query(query, parameter,
        (err, results) => {
          if (err) {
            res.status(500).send(err);
            console.log(timestamp + "Error Push Cart Data", err);
          } else {
            res.status(200).send(results);
            console.log(timestamp + `push cart header ${user_id}`);
            addSqlLogger(req.dataToken.user_id, (query.concat(parameter)), (JSON.stringify(results)), 'addCartHeader');
          }
        }
      );

    } else {
      res.status(401).send({
        success: false,
        message: 'Unautorized!'
      });
    }
  },
  addCartDetail: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';
    // timestamp + 


    if (req.dataToken.user_id) {

      // patch: added delv_week
      let {
        cart_id,
        user_id,
        company_id,
        detail_id,
        cont_size,
        cont_qty,
        sku1,
        sku2,
        sku3,
        qty1,
        qty2,
        qty3,
        price1,
        price2,
        price3,
        remarks,
        bulk,
        delv_week,
        delv_year,
        id_year
      } = req.body;

      let query = ` INSERT INTO m_cart_dtl
                    (cart_id, company_id, created_by, detail_id, 
                      cont_size, cont_qty, 
                      sku1, sku2, sku3, qty1, qty2, qty3, price1, price2, price3, 
                      remarks, bulk, delv_week, delv_year, id_year,
                      created_date)
                    VALUES
                    (?, ?, ?, ?, ?, ?,  ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,
                      date_format(now(),'%Y-%m-%d-%T '));
                  `;

      let parameter = [
        cart_id, company_id, user_id, detail_id,
        cont_size, cont_qty,
        sku1, sku2, sku3, qty1, qty2, qty3,
        price1, price2, price3, remarks, bulk, delv_week, delv_year, id_year
      ]
      dbConf.query(query, parameter,
        (err, results) => {
          if (err) {
            res.status(500).send(err);
            console.log(timestamp + "Error Push Cart Data", err);
          } else {
            res.status(200).send(results);
            console.log(timestamp + `push cart detail for ${user_id} success`);
            addSqlLogger(req.dataToken.user_id, (query.concat(parameter)), (JSON.stringify(results)), `addCartDetail-${detail_id}`);
          }
        }
      );



    } else {
      res.status(401).send({
        success: false,
        message: 'Unautorized!'
      });
    }
  },
  getCart_id: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';

    try {
      if (req.dataToken.user_id) {

        let query = `SELECT  MAX(cart_id) AS LATEST
        FROM m_cart
        WHERE created_by = ${req.dataToken.user_id} ;`;

        dbConf.query(query, (err, results) => {
          if (err) {
            res.status(500).send(err);
            console.log(timestamp + "Error get cart id", err);
          } else {
            res.status(200).send(results);
            console.log(timestamp + "get cart_id success:", results[0].LATEST);
            addSqlLogger(req.dataToken.user_id, query, (JSON.stringify(results)), 'getCart_id');
          }
        });

      } else {

        res.status(200).send({
          success: false,
          message: "unauthorized",
        });

      }

    } catch (error) {
      console.log(timestamp + error);
      res.status(500).send(error);
    }
  },
  editCartHeader: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';
    // timestamp + 

    if (req.dataToken.user_id) {

      let {
        cart_id,
        delv_week,
        delv_week_desc,
        delv_year,
        id_year,
        po_buyer,
        port_shipment,
        ship_to,
        created_date,
        po_url,
        user_id,
        company_id,
      } = req.body;

      // let sqlDelete = await dbQuery(` DELETE FROM m_cart WHERE company_id = ${req.dataToken.company_id} AND created_date = '${created_date}';  DELETE FROM m_cart_dtl WHERE company_id = ${req.dataToken.company_id} AND created_date = '${created_date}';`);

      let query = ` INSERT INTO m_cart 
      (cart_id, company_id, delv_week, delv_week_desc, delv_year, id_year,
      po_buyer, created_date, port_shipment, ship_to, po_url, created_by )
      VALUES
      (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);`

      let parameter = [
        cart_id, company_id, delv_week, delv_week_desc, delv_year, id_year,
        po_buyer, created_date, port_shipment, ship_to, po_url, user_id
      ]
      dbConf.query(
        // `         
        //       UPDATE m_cart
        //       SET delv_week = ${delv_week}, 
        //       delv_week_desc = ${rev_delv_week_desc}, 
        //       po_buyer = ${rev_po_buyer}, 
        //       port_shipment = ${port_shipment}, ship_to = ${ship_to},
        //       po_url = ${rev_po_url}
        //       WHERE cart_id = ${cart_id} AND created_date = ${rev_created_date}
        //       ;`
        query, parameter, (err, results) => {
          if (err) {
            res.status(500).send(err);
            console.log(timestamp + "Error updateCartHeader", err);
          } else {

            res.status(200).send(results);
            console.log(timestamp + "update Cart Header success cart_id:" + cart_id);
            addSqlLogger(req.dataToken.user_id, (query.concat(parameter)), (JSON.stringify(results)), 'editCartHeader');
          }
        }
      );

    } else {
      res.status(401).send({
        success: false,
        message: 'Unautorized!'
      });
    }
  },
  editCartDetail: async (req, res) => {

    let date = new Date();
    let timestamp = magenta + date.toLocaleDateString('id') + ' ' + date.toLocaleTimeString('id') + ' : ' + ' ';
    // timestamp + 

    if (req.dataToken.user_id) {

      let {
        cart_id,
        cont_size,
        cont_qty,
        sku1,
        sku2,
        sku3,
        qty1,
        qty2,
        qty3,
        price1,
        price2,
        price3,
        remarks,
        bulk,
        delv_week,
        delv_year,
        id_year,
        created_date,
        user_id,
        company_id,
        detail_id,
      } = req.body;

      let rev_remarks = "'" + remarks + "'";
      let rev_created_date = "'" + created_date + "'";

      // let sqlDelete = await dbQuery(` DELETE FROM m_cart_dtl WHERE company_id = ${req.dataToken.company_id} AND created_date = '${created_date}';`);

      let query = `   INSERT INTO m_cart_dtl
      (cart_id, company_id, created_by, detail_id, 
      cont_size, cont_qty, 
      sku1, sku2, sku3, qty1, qty2, qty3, price1, price2, price3, 
      remarks, bulk, delv_week, delv_year, id_year, 
      created_date)
      VALUES
      (?, ?, ?, ?, 
      ?, ?, 
      ?, ?, ?, ?, ?, ?,
      ?, ?, ?,
      ?, ?, ?, ?, ?, 
      ?)
      ; `;

      let parameter = [cart_id, company_id, user_id, detail_id,
        cont_size, cont_qty,
        sku1, sku2, sku3, qty1, qty2, qty3,
        price1, price2, price3,
        remarks, bulk, delv_week, delv_year, id_year,
        created_date]

      dbConf.query(
        // `        
        //       UPDATE m_cart_dtl 
        //       SET cont_size = ${cont_size}, cont_qty = ${cont_qty}, 
        //       sku1 = ${sku1}, sku2 = ${sku2},sku3 = ${sku3},
        //       qty1 = ${qty1}, qty2 = ${qty2}, qty3 = ${qty3},
        //       price1 = ${price1}, price2 = ${price2},  price3 = ${price3},
        //       remarks = ${rev_remarks}, bulk = ${bulk}, 
        //       delv_week = ${delv_week}, 
        //       detail_id=${detail_id}  
        //       WHERE cart_id = ${cart_id} AND created_date = ${rev_created_date}
        //       ;`
        query, parameter, (err, results) => {
          if (err) {
            res.status(500).send(err);
            console.log(timestamp + "Error updateCartHeader", err);
          }
          res.status(200).send(results);
          console.log(timestamp +
            `update Cart Detail success for ${cart_id} and ${rev_created_date}`
          );
          addSqlLogger(req.dataToken.user_id, (query.concat(parameter)), (JSON.stringify(results)), 'editCartDetail')
        }

      );



    } else {
      res.status(401).send({
        success: false,
        message: 'Unautorized!'
      });
    }

  },
};
